<!DOCTYPE html>
<html>
    <head>
        <title>学校管理员页面</title>
        <script src="https://cdn.staticfile.org/jquery/3.4.0/jquery.min.js"></script>
        
    <script src="https://unpkg.com/sweetalert2@11.4.19/dist/sweetalert2.all.js"></script>
    <script src="https://cdn.staticfile.org/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui/dist/css/mdui.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/mdui/dist/js/mdui.min.js" ></script>
    <script src="/studentmanagement/index.js"></script>
    <script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
    </head>
    <body>
        <a href="studentmanagement/">管理学生</a>
        <a href="teachermanagement/">管理教师</a>
        <a href="addexam/">添加考试</a>
    </body>
</html>
