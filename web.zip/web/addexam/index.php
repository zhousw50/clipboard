<html>
<head>
    <title>添加试卷</title>
    <script src="https://unpkg.com/sweetalert2@11.4.19/dist/sweetalert2.all.js"></script>
    <script src="https://cdn.staticfile.org/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui/dist/css/mdui.min.css">
    <script src="https://cdn.jsdelivr.net/npm/mdui/dist/js/mdui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/zhousw50/tools/header.min.js"></script>
    <style>
        input{width:50px;}
    </style>
</head>

<body class="mdui-theme-primary-indigo mdui-theme-accent-indigo mdui-appbar-with-toolbar mdui-appbar-with-tab">
<header></header>
<div class="mdui-container mdui-card"><h1 class="mdui-card-primary-title">试卷设置</h1><div class="mdui-card-content">
图片url<input oninput="document.getElementById('img').setAttribute('src','./getmouse.php?img='+this.value);document.getElementById('img').setAttribute('style','width:100%;height:500px;');" class="mdui-textfield-input"><br>
<iframe id="img" frameborder="0" style="display:none;"></iframe><br>
考号<input value="5" id="kaohao" style="width:25px">位数
<div id="1"></div>
选择题数目<input id="number2">
<div id="2"></div>
非选题数目<input id="number3">
<div id="3"></div>
<button class="mdui-btn mdui-ripple mdui-btn-block mdui-color-pink">添加</button>
    </div></div>
<script>
    header({
        color:"indigo",
        header_title:"添加试卷",
        header_link:"./"
    })
    document.getElementById("kaohao").oninput=function (){set()}
    function set(){
        if(document.getElementById("kaohao").value>15)Swal.fire("位数太多啦").then(()=>(window.location.reload()))
        var a="";
        a += "<div class=\"mdui-table-fluid\">";
        a += "        <table class=\"mdui-table mdui-table-hoverable mdui-table-col-numeric\">";
        a += "            <tr>";
        for(var i=1;i<=document.getElementById("kaohao").value;i++)a += "                <th>第"+i+"列<\/th>";
        a += "            <\/tr>";
        for(var j=0;j<10;j++) {
            a += "            <tr>";
            for (var i = 1; i <= document.getElementById("kaohao").value; i++) a += "                <th><span>数字"+j+"<\/span>左上x:<input id='zuoshang-kaohao-"+i+"-"+j+"-x'>y:<input id='zuoshang-kaohao-"+i+"-"+j+"-y'>右下x:<input id='yousia-kaohao-"+i+"-"+j+"-x'>y:<input id='yousia-kaohao-"+i+"-"+j+"-y'><\/th>";
            a += "            <tr>";
            a += "            <\/tr>";
        }
        a += "        <\/table>";
        a += "    <\/div>";
        document.getElementById("1").innerHTML=a;
        //console.log(document.getElementById("kaohao").value);
    }
    set();
    document.getElementById("number2").oninput=function (){
        var a="";
        if(this.value>300)Swal.fire("太多啦").then(()=>(this.value=0))
        for(var i=1;i<=this.value;i++){
            a += "<span>第<input value='"+i+"' id='timunumber"+i+"'>题<\/span>";
            a+=' 正确选项<select class="mdui-select" id="choose-'+i+'" mdui-select>'
                +'<option value="A">A</option>'
            +'<option value="B">B</option>'
            +'<option value="C">C</option>'
            +'<option value="D">D</option>'
                +'<option value="E">E</option>'
                +'<option value="F">F</option>'
                +'<option value="G">G</option>'
        +'</select> 左上x:<input id="zuoshang-choose-x-'+i+'">y:<input id="zuoshang-choose-y-'+i+'">右下x:<input id="youxia-choose-x-'+i+'">y:<input id="youxia-choose-y-'+i+'"><br>';
        }
        document.getElementById("2").innerHTML=a;
    }
    document.getElementById("number3").oninput=function (){
        var a="";
        if(this.value>300)Swal.fire("太多啦").then(()=>(this.value=0))
        for(var i=1;i<=this.value;i++){
            var zzz=parseInt(i)+parseInt(document.getElementById('number2').value)
            a += "<span>第<input value='"+zzz+"' id='timunumber-"+zzz+"'>题<\/span>";
            a += '左上x:<input id="zuoshang-x-'+i+'">y:<input id="zuoshang-y-'+i+'">右下x:<input id="youxia-x-'+i+'">y:<input id="youxia-y-'+i+'"><br>';
        }
        document.getElementById("3").innerHTML=a;
    }
</script>
</body>
</html>