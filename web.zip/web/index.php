<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>改卷系统(开发中)</title>
    <script src="https://unpkg.com/sweetalert2@11.4.19/dist/sweetalert2.all.js"></script>
    <script src="https://cdn.staticfile.org/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui/dist/css/mdui.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/mdui/dist/js/mdui.min.js" ></script>
    <script src="config.js"></script>
    <script src="https://unpkg.com/sweetalert2@11.4.19/dist/sweetalert2.all.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/zhousw50/tools/header.min.js"></script>
</head>

<body class="mdui-appbar-with-toolbar mdui-appbar-with-tab">
<header></header>
<div class="mdui-container mdui-card"><h1 class="mdui-card-primary-title"></h1><div class="mdui-card-content">
    <script>
        header({color:"indigo",header_title:"登录页面",header_link:"./"});
        $(document).ready(function() {
            $("#1").click(function() {
        school()
            }) 
            $("#3").click(function() {
        student()
            }) 
            if (getCookie("loginas")=="school")
            window.location.href = "school.php";
        })
        var name1,p1,p2
        function createCookie(name,value,days,path,domain,secure){
            if(days){
                var date = new Date();
                date.setTime(date.getTime()+(days*24*60*60*1000));
                var expires = date.toGMTString();
            }
            else var expires = "";
            cookieString = name + "=" +value;
            if(expires) cookieString += ";expires=" +expires;
            if(path) cookieString += ";path=" + escape(path);
            if(domain) cookieString += ";domain=" + escape(domain);
            if(secure) cookieString += ";secure=" + escape(secure);
            document.cookie = cookieString;
        }
        function getCookie(name)
        {
            var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
            if(arr=document.cookie.match(reg))
                return unescape(arr[2]);
            else
                return null;
        }
        function sub() {
            name1=document.getElementById("name").value;
            p1=document.getElementById("p1").value;
            p2=document.getElementById("p2").value;
            Swal.clickConfirm()
            if(name1==schoolname||p1==password1||p2==password2){
                Swal.fire({icon:"success",title:"登录成功",timer:1000,showConfirmButton: false}).then(() => {
                    createCookie("loginas","school",9e50);
                    window.location.reload()
                });
            }
            else {
                Swal.fire({icon:"error",title:"登录失败",timer:1000,showConfirmButton: false}).then(() => {
                    window.location.reload()
                });
            }
        }
        function school(){
            Swal.fire({
                showConfirmButton: false,
                allowEscapeKey:false,
                allowOutsideClick:false,
                icon: 'info',
                title: '以学校管理员登陆',
                html:"名称<input id='name'><br>密码1<input id='p1'><br>密码2<input id='p2'><br><button onclick='sub()' class=\"swal2-confirm swal2-styled\" aria-label style=\"display: inline-block;\">确定</button>"
            })
        }
        function student(){
            Swal.fire({
                showConfirmButton: false,
                allowEscapeKey:false,
                allowOutsideClick:false,
                icon: 'info',
                title: '以学生登陆',
                html:"<form action=\"student.php\" method=\"post\">名称<input name='name'><br>密码<input name='p'><br><button name=\"submit\" class=\"swal2-confirm swal2-styled\" aria-label style=\"display: inline-block;\">确定</button>"
            })
        }
    </script>
	以<button id="1">学校管理人员</button>
	<button id="2">老师</button>
	<button id="3">学生</button>
	身份登录
    </div></div>
</body>

</html>