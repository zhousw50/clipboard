var schoolname="dzzx"
var password1="qwer"
var password2="qwerty"